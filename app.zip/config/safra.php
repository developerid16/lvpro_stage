<?php
return [
    // 'date-format' =>  'd-m-Y',
    'date-format' => 'Y-m-d H:i:s',
    'date-only' => 'Y-m-d',
    'month-format' =>  'Y-m',
    'apiusername' =>  env('apiusername', 'API9LS9MPTHXA'),
    'apipassword' =>  env('apipassword', 'API9LS9MPTHXAF6B2U'),
    'senderid' =>  env('senderid', 'Safra SG'),
    'languagetype' =>  env('languagetype',1),
];
