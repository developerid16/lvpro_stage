<?php

namespace App\Models;

use App\Traits\AddsAddedBy;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RewardUpdateRequest extends Model
{
    use HasFactory, AddsAddedBy;
  

    protected $table = "reward_update_requests";
    protected $fillable = [
        'reward_id',    
        'request_by',
        'voucher_image',
        'voucher_detail_img',
        'name',
        'description',
        'term_of_use',
        'how_to_use',
        'merchant_id',
        'reward_type',
        'usual_price',
        'publish_start_date',
        'publish_start_time',
        'publish_end_date',
        'publish_end_time',
        'sales_start_date',
        'sales_start_time',
        'sales_end_date',
        'sales_end_time',
        'max_quantity',
        'low_stock_1',
        'low_stock_2',
        'friendly_url',
        'category_id',
        'club_classification_id',
        'fabs_category_id',
        'smc_classification_id',
        'ax_item_code',
        'publish_independent',
        'publish_inhouse',
        'send_reminder',       
        'hide_quantity', 
            
        'max_order',     
        'location_text',     
        'participating_merchant_id',     
        'voucher_validity',
        'where_use',  
        'inventory_qty',
        'inventory_type',
        'voucher_value' ,  
        'voucher_set' , 
        'set_qty', 
        'clearing_method' ,  
        'csvFile',
        'type',
        'direct_utilization',
        'category_id',
        'month',
        'club_location',
        'from_month',
        'to_month',
        'cso_method',
        'is_draft',
        'days',
        'start_time',
        'end_time',
        'suspend_deal',
        'suspend_voucher',
        'purchased_qty',
        'status',
        'added_by',
        'is_featured',
        'hide_catalogue',
        'hide_cat_time'
        
    
    ];

   protected $casts = [
        'sales_start_date' => 'date',
        'sales_end_date' => 'date',
        'voucher_validity' => 'date',
        'publish_start_date' => 'date',
        'publish_end_date'   => 'date',  
        'days' => 'array',    
    ];

    public function requester()
    {
        return $this->belongsTo(User::class, 'request_by');
    }

    public function reward()
    {
        return $this->belongsTo(Reward::class);
    }

    public function tierRates()
    {
        return $this->hasMany(
            RewardTierRate::class,
            'reward_id',   // FK in reward_tier_rates
            'reward_id'    // local key in reward_update_requests
        );
    }
   

    public function participatingLocations()
    {
        return $this->hasMany(
            ParticipatingLocations::class,
            'reward_id',
            'reward_id'
        );
    }

    public function locations()
    {
        $locationIds = $this->location_ids;
        if (empty($locationIds)) {
            return collect([]);
        }
        return Location::whereIn('id', $locationIds)->get();
    }
    public function rewardLocations()
    {
        return $this->hasMany(
            RewardLocationUpdate::class,
            'reward_id',
            'reward_id'
        );
    }


    public function rewardDates()
    {
        return $this->hasMany(\App\Models\RewardDates::class);
    }
   public function customLocation()
    {
        return $this->belongsTo(CustomLocation::class, 'location_text', 'id');
    }

   
}
