@extends('layouts.master-layouts')

@section('title')
    Birthday Voucher
@endsection
@section('content')
    @component('components.breadcrumb')
        @slot('li_1')
            Admin
        @endslot
        @slot('li_1_link')
            {{ url('/') }}
        @endslot
        @slot('title')
            Birthday Voucher Management
        @endslot
    @endcomponent


    <div class="card">
        <div class="card-header bg-white d-flex justify-content-between align-items-center border-bottom mb-3">
            {{-- <h4 class="card-title mb-0">Rewards</h4> --}}
           
            @can("$permission_prefix-create")
            <button class="sh_btn ml_auto btn btn-primary" data-bs-toggle="modal" data-bs-target="#AddModal" onclick="resetFormById()"><i class="mdi mdi-plus"></i>Add New</button>
            @endcan
        </div>

        <div class="card-body pt-0">
            <div class="table-responsive">
                <table class="sh_table table table-bordered" id="bstable" data-toggle="table"
                    data-page-list="[100, 500, 1000, 2000, All]" data-search-time-out="1200" data-page-size="100"
                    data-ajax="ajaxRequest" data-side-pagination="server" data-pagination="true" data-search="false"
                    data-total-field="count" data-data-field="items" data-show-columns="false" data-show-toggle="false"
                    data-show-export="false" data-filter-control="true" data-show-columns-toggle-all="false">
                    <thead>
                        <tr>
                            <th data-field="sr_no" data-filter-control="input" data-sortable="false" data-width="75"
                                data-width-unit="px" data-searchable="false">Sr. No.</th>
                                <th data-field="month">Voucher Creation</th>
                          
                            <th data-field="name" data-filter-control="input" data-sortable="true" data-escape="true">Name</th>
                             <th data-field="quantity" data-filter-control="input" data-sortable="true">Total</th>
                            <th data-field="redeemed">Redeemed</th>
                            <th data-field="image">Image</th>
                            <th data-field="status">Status</th>
                            <th data-field="created_at">Created On</th>
                            <th class="text-center" data-field="action" data-searchable="false">Action</th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>

    <!-- Create -->
    @can("$permission_prefix-create")
        @include('admin.birthday-voucher.add-edit-modal')
    @endcan
    <!-- end modal -->

  
    <div class="modal fade" id="monthSelectModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">

                <!-- HEADER -->
                <div class="modal-header">
                    <h5 class="modal-title">
                        Select Month
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <!-- BODY -->
                <div class="modal-body">

                    <!-- Year Dropdown -->
                    <div class="mb-4">
                        <label class="form-label fw-semibold">Select Year</label>
                        <select class="form-select" id="yearSelect"></select>
                    </div>

                    <p class="mb-3 text-muted">
                        You want to add this voucher in which month?
                    </p>

                    <!-- Month Grid -->
                    <div class="row" id="monthList"></div>

                </div>

                <!-- FOOTER -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        Cancel
                    </button>
                    <button type="button" class="btn btn-primary" id="confirmMonths">
                        Confirm
                    </button>
                </div>

            </div>
        </div>
    </div>



@endsection

@section('script')

    <script>
        window.selectedOutletMap = {}; 

        document.getElementById('csvFile').addEventListener('change', function (e) {
            const file = e.target.files[0];
            if (!file) return;

            const reader = new FileReader();

            reader.onload = function (evt) {
                const data = new Uint8Array(evt.target.result);
                const workbook = XLSX.read(data, { type: 'array' });

                const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
                const rows = XLSX.utils.sheet_to_json(firstSheet, { defval: '' });

                const count = rows.length;

                // show inventory field
                const inventoryDiv = document.querySelector('.inventory_qty');
                inventoryDiv.style.display = 'block';

                const inventoryInput = document.getElementById('inventory_qty');
                calculateSetQty();
                inventoryInput.value = count;

                inventoryInput.readOnly = true;

                $('#uploadedFileLink').text(file.name).attr('href', 'javascript:void(0)');
                $('#uploadedFile').removeClass('d-none').addClass('d-flex');            
            };

            reader.readAsArrayBuffer(file);
        });
        
        $(document).on('click', '#removeCsvFile', function () {
            $('#csvFile').val('');
            $('#uploadedFileLink').text('').attr('href', 'javascript:void(0)');
            $('#uploadedFile').removeClass('d-flex').addClass('d-none');
        });

    </script>
    <script>
        var ModuleBaseUrl = "{{ $module_base_url }}/";
        var DataTableUrl = ModuleBaseUrl + "datatable";
        var digitalMerChants = [];

        function ajaxRequest(params) {
            $.get(DataTableUrl + '?' + $.param(params.data)).then(function(res) {
                $('.fixed-table-body .fixed-table-loading').removeClass('open');
                params.success(res)
            })
        }  
       
       function imagePreview(inputSelector, previewSelector) {
            $(document).on("change", inputSelector, function () {
                let file = this.files[0];
                let preview = $(previewSelector);

                if (!file) {
                    preview.attr("src", "").hide();
                    return;
                }

                let reader = new FileReader();
                reader.onload = function (e) {
                    preview.attr("src", e.target.result).show();
                };

                reader.readAsDataURL(file);
            });
        }

        imagePreview("#voucher_image", "#voucher_image_preview");
        imagePreview("#voucher_detail_img", "#voucher_detail_img_preview");

        $(document).on('shown.bs.modal','#EditModal', function () {
            const $modal = $(this);

            function togglePhysicalSectionInModal() {
                const val = $modal.find('.reward_type').val();
                if (val === undefined) return;
                $modal.find('#physical').toggle(val == "1");
            }

            // bind change (scoped to this modal)
            $modal.find('.reward_type').off('change.togglePhysical').on('change.togglePhysical', togglePhysicalSectionInModal);

            // initial toggle for edit mode
            togglePhysicalSectionInModal();
        });

        $(document).on("change", ".inventory_type", function () {
            let modal = $(this).closest(".modal");
            toggleInventoryFields(modal);
        });

        $(document).on("change", ".clearing_method", function () {
            let modal = $(this).closest(".modal");
            toggleClearingFields(modal);
        });

        $(document).on('change', '#AddModal #participating_merchant_id', function () {

            const modal      = $(this).closest('.modal');   // ✅ modal context
            const merchantIds = $(this).val();               // array or null

            if (merchantIds && merchantIds.length > 0) {
                modal.find("#participating_section").show();
                modal.find("#participating_merchant_location").show();
            } else {
                // only hide LEFT section, NOT selected summary
                modal.find("#participating_merchant_location").empty();
                modal.find("#participating_section").hide();
            }
        }); 
          
    </script>
    <script>
       

        $(document).on('change', '#AddModal #participating_merchant_id', function () {

            $('.club-location-error').text('');
            const modal      = $(this).closest('.modal');   // ✅ modal context
            const merchantIds = $(this).val();               // array or null

            if (merchantIds && merchantIds.length > 0) {
                modal.find("#participating_section").show();
                modal.find("#participating_merchant_location").show();

                loadParticipatingMerchantLocationsBday(modal,merchantIds);
            } else {
                // only hide LEFT section, NOT selected summary
                modal.find("#participating_merchant_location").empty();
                modal.find("#participating_section").hide();
            }
        });
        


        $(document).on('shown.bs.modal', '#AddModal', function () {
            initEditor();
            
            $('#clear_voucher_detail_img').hide();
            $('#clear_voucher_image').hide();
            $('.outlet-container').hide();
            $(".where_use").hide();
             bindMonthFlatpickr(this);
            initFlatpickrDate();
        });
      
        $(document).on("change", ".reward_id", function () {
            let id = $(this).val();

            if (!id) {
                $("input[name='publish_start']").val("");
                $("input[name='publish_end']").val("");
                return;
            }

            $.ajax({
                url: "{{ url('admin/reward/get-dates') }}/" + id,
                type: "GET",
                success: function (res) {
                    if (res.publish_start) {
                        $("input[name='publish_start']").val(res.publish_start);
                    }

                    if (res.publish_end) {
                        $("input[name='publish_end']").val(res.publish_end);
                    }
                }
            });
        });    


        $(document).on('input', '#inventory_qty', calculateSetQty);

        // when voucher_set changes
        $(document).on('input', '#voucher_set', calculateSetQty);

        $(document).on('input', '#voucher_value', calculateSetQty);

        function calculateSetQty() {
            let inventoryQty = parseFloat($('#inventory_qty').val());
            let voucherSet   = parseFloat($('#voucher_set').val());
            if (!isNaN(inventoryQty) && !isNaN(voucherSet) && voucherSet > 0) {
                $('#set_qty').val(Math.floor(inventoryQty / voucherSet));
            } else {
                $('#set_qty').val('');
            }
        }
        function resetFormById() {
            let modal = $('#AddModal').closest(".modal");
        
            $(".participating_merchant").hide();
            $("#voucher_image_preview").hide();
            $("#participating_merchant_location").hide();
            $(".file").hide();
            $(".inventory_qty").hide();
            $('.club_location').val(null).trigger('change');

            window.selectedOutletMap = {};               // clear JS memory
            modal.find("#selected_locations_summary").empty();
            modal.find("#selected_locations_wrapper").hide();
            modal.find("#selected_locations_hidden").empty();

            let form = document.getElementById('add_frm');
            if (!form) return;

            // BASIC RESET
            form.reset();

            // CLEAR FILE INPUTS
            form.querySelectorAll('input[type="file"]').forEach(file => {
                file.value = '';
            });

        

            // OPTIONAL: hide error messages
            form.querySelectorAll('.is-invalid').forEach(el => el.classList.remove('is-invalid'));
            form.querySelectorAll('.invalid-feedback').forEach(el => el.remove());
        }

    </script>
    <script src="{{ URL::asset('build/js/crud.js') }}"></script>
@endsection
