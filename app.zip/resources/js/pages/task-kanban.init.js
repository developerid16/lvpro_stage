/*

File: task kanban Init Js File
*/

dragula([
    document.getElementById("upcoming-task"), 
    document.getElementById("inprogress-task"),
    document.getElementById("complete-task")
]);