/*

File: ecommerce select2 Js File
*/

// Select2
$(".select2").select2();