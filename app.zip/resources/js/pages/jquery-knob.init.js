/*

File: Jquery knob init Js File
*/

$(function() {
    $(".knob").knob();
});