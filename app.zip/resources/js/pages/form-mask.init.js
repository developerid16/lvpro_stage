/*

File: Form mask Js File
*/

$(document).ready(function(){
    $(".input-mask").inputmask();
});